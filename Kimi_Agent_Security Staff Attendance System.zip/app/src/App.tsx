import { useState } from 'react';
import { LoginSection } from '@/sections/LoginSection';
import { GWriterSection } from '@/sections/GWriterSection';
import { OfficerSection } from '@/sections/OfficerSection';
import { useAttendance } from '@/hooks/useAttendance';
import type { Staff, StaffStatus, User } from '@/types';

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const { 
    staffDatabase,
    login, 
    logout, 
    registerStaff,
    editStaff,
    removeStaff,
    submitAttendance, 
    getTodayStatus,
    getStaffWithAttendance,
    getStatistics,
    getStaffByRank,
  } = useAttendance();

  const handleLogin = (accessCode: string): { success: boolean; user?: User } => {
    const result = login(accessCode);
    if (result.success && result.user) {
      setCurrentUser(result.user);
    }
    return result;
  };

  const handleLogout = () => {
    logout();
    setCurrentUser(null);
  };

  const handleRegisterStaff = (staff: Staff): boolean => {
    return registerStaff(staff);
  };

  const handleEditStaff = (serviceNumber: string, updatedStaff: Partial<Staff>): boolean => {
    return editStaff(serviceNumber, updatedStaff);
  };

  const handleRemoveStaff = (serviceNumber: string): boolean => {
    return removeStaff(serviceNumber);
  };

  const handleSubmitAttendance = (serviceNumber: string, status: StaffStatus): boolean => {
    return submitAttendance(serviceNumber, status);
  };

  // Render based on user role
  if (!currentUser) {
    return <LoginSection onLogin={handleLogin} />;
  }

  // G-Writer: Limited access - can register staff, edit staff, remove staff, and log attendance
  if (currentUser.role === 'g-writer') {
    return (
      <GWriterSection
        user={currentUser}
        staffList={staffDatabase}
        onLogout={handleLogout}
        onRegisterStaff={handleRegisterStaff}
        onEditStaff={handleEditStaff}
        onRemoveStaff={handleRemoveStaff}
        onSubmitAttendance={handleSubmitAttendance}
        getTodayStatus={getTodayStatus}
      />
    );
  }

  // Commanding Officer & Executive Officer: Full clearance
  if (currentUser.role === 'commanding-officer' || currentUser.role === 'executive-officer') {
    return (
      <OfficerSection
        user={currentUser}
        staffList={getStaffWithAttendance()}
        staffByRank={getStaffByRank()}
        statistics={getStatistics()}
        onLogout={handleLogout}
      />
    );
  }

  // Fallback to login
  return <LoginSection onLogin={handleLogin} />;
}

export default App;
