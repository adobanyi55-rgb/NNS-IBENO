import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, AlertCircle, Lock } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { User } from '@/types';

interface LoginSectionProps {
  onLogin: (accessCode: string) => { success: boolean; user?: User };
}

export function LoginSection({ onLogin }: LoginSectionProps) {
  const [accessCode, setAccessCode] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!accessCode.trim()) {
      setError('Please enter your Access Code');
      return;
    }

    setIsSubmitting(true);
    
    setTimeout(() => {
      const result = onLogin(accessCode.trim());
      if (!result.success) {
        setError('Invalid Access Code. Please try again.');
      }
      setIsSubmitting(false);
    }, 300);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="w-full max-w-md">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br from-blue-600 to-blue-800 mb-4 shadow-lg shadow-blue-600/30 border-4 border-slate-700">
            <Shield className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2 tracking-wide">
            PARADE STATE
          </h1>
          <h2 className="text-xl font-semibold text-blue-400 mb-2">
            MONITORING SYSTEM
          </h2>
          <p className="text-slate-400">
            Daily Personnel Status Tracking
          </p>
        </div>

        <Card className="border-slate-700 bg-slate-800/90 backdrop-blur-sm shadow-xl">
          <CardHeader className="space-y-1">
            <CardTitle className="text-xl text-white flex items-center gap-2">
              <Lock className="w-5 h-5 text-blue-400" />
              Secure Access
            </CardTitle>
            <CardDescription className="text-slate-400">
              Enter your unique Access Code to proceed
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert variant="destructive" className="bg-red-900/50 border-red-700">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <div className="space-y-2">
                <label htmlFor="accessCode" className="text-sm font-medium text-slate-300">
                  Access Code
                </label>
                <Input
                  id="accessCode"
                  type="password"
                  placeholder="Enter access code"
                  value={accessCode}
                  onChange={(e) => setAccessCode(e.target.value.toUpperCase())}
                  className="bg-slate-900 border-slate-600 text-white placeholder:text-slate-500 focus:border-blue-500 focus:ring-blue-500"
                  disabled={isSubmitting}
                  autoFocus
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Authenticating...' : 'Access System'}
              </Button>
            </form>

            <div className="mt-6 pt-4 border-t border-slate-700">
              <p className="text-xs text-center text-slate-500 mb-2">
                <span className="font-semibold text-slate-400">Authorized Personnel Only</span>
              </p>
              <p className="text-xs text-center text-slate-600">
                CO: CO2024 | XO: XO2024 | G-Writer: GW2024
              </p>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-slate-600 text-sm mt-6">
          Military Personnel Management System v2.0
        </p>
      </div>
    </div>
  );
}
