import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Shield, 
  LogOut, 
  Users, 
  Search,
  Filter,
  BarChart3,
  Clock,
  Moon,
  Ticket,
  Briefcase,
  HeartPulse,
  Target,
  AlertCircle,
  Ship,
  Anchor,
  Plane,
  X,
  Printer
} from 'lucide-react';
import type { StaffWithAttendance, StaffStatus, User as UserType } from '@/types';
import { statusOptions, rankLabels } from '@/data/staff';
import { cn } from '@/lib/utils';

interface OfficerSectionProps {
  user: UserType;
  staffList: StaffWithAttendance[];
  staffByRank: {
    officers: StaffWithAttendance[];
    seniorRates: StaffWithAttendance[];
    juniorRates: StaffWithAttendance[];
  };
  statistics: Record<string, number>;
  onLogout: () => void;
}

const iconMap: Record<string, React.ElementType> = {
  Ship,
  Anchor,
  Moon,
  Ticket,
  Plane,
  Briefcase,
  HeartPulse,
  Target,
  Clock,
};

const statColors: Record<string, string> = {
  'Strength': 'bg-slate-600',
  'Checked In': 'bg-blue-600',
  'Onboard': 'bg-green-600',
  'Ashore': 'bg-blue-500',
  'Off Duty': 'bg-slate-500',
  'Pass': 'bg-teal-500',
  'Leave': 'bg-indigo-500',
  'Temp Duty': 'bg-purple-500',
  'Sick': 'bg-red-500',
  'Operations': 'bg-orange-500',
  'Yet to Report': 'bg-yellow-500',
};

const statusValueMap: Record<string, StaffStatus | null> = {
  'Onboard': 'onboard',
  'Ashore': 'ashore',
  'Off Duty': 'off-duty',
  'Pass': 'pass',
  'Leave': 'leave',
  'Temp Duty': 'temp-duty',
  'Sick': 'sick',
  'Operations': 'operations',
  'Yet to Report': null,
};

export function OfficerSection({ user, staffList, staffByRank, statistics, onLogout }: OfficerSectionProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<StaffStatus | 'all' | null>('all');
  const [selectedStatusDetail, setSelectedStatusDetail] = useState<StaffStatus | null | 'all'>('all');
  const [showDetailModal, setShowDetailModal] = useState(false);

  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const currentDateFormatted = new Date().toLocaleDateString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });

  // Filter staff based on search and status
  const filteredStaff = staffList.filter(staff => {
    const matchesSearch = 
      staff.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.serviceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.position.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || staff.todayStatus === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const totalStaff = staffList.length;

  const handleStatClick = (label: string) => {
    if (label === 'Strength' || label === 'Checked In') {
      setSelectedStatusDetail('all');
    } else {
      const statusValue = statusValueMap[label];
      setSelectedStatusDetail(statusValue);
    }
    setShowDetailModal(true);
  };

  const getDetailStaff = () => {
    if (selectedStatusDetail === 'all') {
      return staffList;
    }
    return staffList.filter(s => s.todayStatus === selectedStatusDetail);
  };

  const getDetailTitle = () => {
    if (selectedStatusDetail === 'all') return 'All Personnel';
    if (selectedStatusDetail === null) return 'Yet to Report';
    const statusConfig = statusOptions.find(s => s.value === selectedStatusDetail);
    return statusConfig?.label || 'Unknown';
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>PARADE STATE REPORT - ${currentDateFormatted}</title>
        <style>
          @page {
            size: A4 portrait;
            margin: 2cm 2cm 2.5cm 2cm;
          }
          body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 14pt;
            line-height: 1.5;
            color: #000;
            margin: 0;
            padding: 0;
          }
          .header {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
            margin-bottom: 20px;
          }
          .restricted-header {
            text-align: center;
            font-weight: bold;
            font-size: 16pt;
            border: 2px solid #000;
            padding: 5px;
            margin-bottom: 15px;
            letter-spacing: 3px;
          }
          .report-title {
            text-align: center;
            font-size: 18pt;
            font-weight: bold;
            margin: 15px 0;
            text-transform: uppercase;
          }
          .report-meta {
            text-align: center;
            margin-bottom: 20px;
          }
          .section-title {
            font-weight: bold;
            font-size: 14pt;
            margin-top: 20px;
            margin-bottom: 10px;
            text-transform: uppercase;
            border-bottom: 1px solid #000;
            padding-bottom: 5px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            font-size: 12pt;
          }
          th, td {
            border: 1px solid #000;
            padding: 6px 8px;
            text-align: left;
          }
          th {
            background-color: #f0f0f0;
            font-weight: bold;
          }
          .stats-table {
            margin-bottom: 20px;
          }
          .stats-table td {
            text-align: center;
          }
          .footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            text-align: center;
            border-top: 2px solid #000;
            padding-top: 10px;
          }
          .restricted-footer {
            font-weight: bold;
            font-size: 16pt;
            border: 2px solid #000;
            padding: 5px;
            display: inline-block;
            letter-spacing: 3px;
          }
          .signature-block {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
          }
          .signature-line {
            width: 200px;
            border-top: 1px solid #000;
            margin-top: 30px;
            text-align: center;
            font-size: 11pt;
          }
          .page-info {
            text-align: center;
            font-size: 10pt;
            margin-top: 10px;
          }
          @media print {
            .no-print { display: none; }
          }
        </style>
      </head>
      <body>
        <!-- RESTRICTED Header -->
        <div class="restricted-header">RESTRICTED</div>
        
        <!-- Report Header -->
        <div class="header">
          <div class="report-title">PARADE STATE REPORT</div>
          <div class="report-meta">
            <strong>Date:</strong> ${currentDateFormatted} | 
            <strong>Unit:</strong> NAVAL OPERATIONS COMMAND | 
            <strong>Report No:</strong> PSR-${new Date().getFullYear()}-${String(new Date().getDate()).padStart(3, '0')}
          </div>
        </div>

        <!-- Summary Statistics -->
        <div class="section-title">Summary</div>
        <table class="stats-table">
          <tr>
            <th>STRENGTH</th>
            <th>CHECKED IN</th>
            <th>ONBOARD</th>
            <th>ASHORE</th>
            <th>OFF DUTY</th>
            <th>PASS</th>
            <th>LEAVE</th>
            <th>SICK</th>
            <th>OPS</th>
            <th>YTR</th>
          </tr>
          <tr>
            <td>${statistics['Strength']}</td>
            <td>${statistics['Checked In']}</td>
            <td>${statistics['Onboard']}</td>
            <td>${statistics['Ashore']}</td>
            <td>${statistics['Off Duty']}</td>
            <td>${statistics['Pass']}</td>
            <td>${statistics['Leave']}</td>
            <td>${statistics['Sick']}</td>
            <td>${statistics['Operations']}</td>
            <td>${statistics['Yet to Report']}</td>
          </tr>
        </table>

        <!-- Officers Section -->
        <div class="section-title">Section A - Officers</div>
        <table>
          <thead>
            <tr>
              <th style="width: 8%">S/N</th>
              <th style="width: 25%">RANK & NAME</th>
              <th style="width: 20%">DEPARTMENT</th>
              <th style="width: 22%">POSITION</th>
              <th style="width: 15%">STATUS</th>
              <th style="width: 10%">REMARKS</th>
            </tr>
          </thead>
          <tbody>
            ${staffByRank.officers.length === 0 ? '<tr><td colspan="6" style="text-align:center">No personnel in this category</td></tr>' : ''}
            ${staffByRank.officers.map((s, i) => {
              const status = s.todayStatus ? statusOptions.find(opt => opt.value === s.todayStatus)?.label : 'YET TO REPORT';
              return `
                <tr>
                  <td>${i + 1}</td>
                  <td>${s.rank} ${s.name}</td>
                  <td>${s.department}</td>
                  <td>${s.position}</td>
                  <td>${status}</td>
                  <td></td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>

        <!-- Senior Rates Section -->
        <div class="section-title">Section B - Senior Rates</div>
        <table>
          <thead>
            <tr>
              <th style="width: 8%">S/N</th>
              <th style="width: 25%">RANK & NAME</th>
              <th style="width: 20%">DEPARTMENT</th>
              <th style="width: 22%">POSITION</th>
              <th style="width: 15%">STATUS</th>
              <th style="width: 10%">REMARKS</th>
            </tr>
          </thead>
          <tbody>
            ${staffByRank.seniorRates.length === 0 ? '<tr><td colspan="6" style="text-align:center">No personnel in this category</td></tr>' : ''}
            ${staffByRank.seniorRates.map((s, i) => {
              const status = s.todayStatus ? statusOptions.find(opt => opt.value === s.todayStatus)?.label : 'YET TO REPORT';
              return `
                <tr>
                  <td>${i + 1}</td>
                  <td>${s.rank} ${s.name}</td>
                  <td>${s.department}</td>
                  <td>${s.position}</td>
                  <td>${status}</td>
                  <td></td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>

        <!-- Junior Rates Section -->
        <div class="section-title">Section C - Junior Rates</div>
        <table>
          <thead>
            <tr>
              <th style="width: 8%">S/N</th>
              <th style="width: 25%">RANK & NAME</th>
              <th style="width: 20%">DEPARTMENT</th>
              <th style="width: 22%">POSITION</th>
              <th style="width: 15%">STATUS</th>
              <th style="width: 10%">REMARKS</th>
            </tr>
          </thead>
          <tbody>
            ${staffByRank.juniorRates.length === 0 ? '<tr><td colspan="6" style="text-align:center">No personnel in this category</td></tr>' : ''}
            ${staffByRank.juniorRates.map((s, i) => {
              const status = s.todayStatus ? statusOptions.find(opt => opt.value === s.todayStatus)?.label : 'YET TO REPORT';
              return `
                <tr>
                  <td>${i + 1}</td>
                  <td>${s.rank} ${s.name}</td>
                  <td>${s.department}</td>
                  <td>${s.position}</td>
                  <td>${status}</td>
                  <td></td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>

        <!-- Signature Block -->
        <div class="signature-block">
          <div>
            <div class="signature-line">G-Writer</div>
            <div style="font-size: 11pt; margin-top: 5px;">Date: ${currentDateFormatted}</div>
          </div>
          <div>
            <div class="signature-line">Executive Officer</div>
            <div style="font-size: 11pt; margin-top: 5px;">Date: _____________</div>
          </div>
          <div>
            <div class="signature-line">Commanding Officer</div>
            <div style="font-size: 11pt; margin-top: 5px;">Date: _____________</div>
          </div>
        </div>

        <!-- Footer -->
        <div class="footer">
          <div class="restricted-footer">RESTRICTED</div>
          <div class="page-info">Page 1 of 1 | Classification: RESTRICTED | Handle in accordance with security regulations</div>
        </div>
      </body>
      </html>
    `;

    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
    }, 250);
  };

  const renderStaffTable = (staff: StaffWithAttendance[], title: string) => {
    if (staff.length === 0) return null;

    return (
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Shield className="w-5 h-5 text-blue-400" />
          {title}
          <Badge className="bg-slate-700">{staff.length}</Badge>
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="text-left py-3 px-4 text-slate-400 font-medium text-sm">Service Number</th>
                <th className="text-left py-3 px-4 text-slate-400 font-medium text-sm">Rank & Name</th>
                <th className="text-left py-3 px-4 text-slate-400 font-medium text-sm">Department</th>
                <th className="text-left py-3 px-4 text-slate-400 font-medium text-sm">Position</th>
                <th className="text-left py-3 px-4 text-slate-400 font-medium text-sm">Current Status</th>
              </tr>
            </thead>
            <tbody>
              {staff.map((s) => {
                const statusConfig = s.todayStatus 
                  ? statusOptions.find(opt => opt.value === s.todayStatus) 
                  : null;
                const StatusIcon = statusConfig ? iconMap[statusConfig.icon] : null;
                
                return (
                  <tr key={s.serviceNumber} className="border-b border-slate-700/50 hover:bg-slate-700/30">
                    <td className="py-3 px-4">
                      <span className="font-mono text-slate-300">{s.serviceNumber}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-white font-medium">{s.rank} {s.name}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-slate-400">{s.department}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-slate-400">{s.position}</span>
                    </td>
                    <td className="py-3 px-4">
                      {statusConfig ? (
                        <Badge className={cn("flex items-center gap-1 w-fit", statusConfig.color)}>
                          {StatusIcon && <StatusIcon className="w-3 h-3" />}
                          {statusConfig.label}
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="border-yellow-600 text-yellow-500 flex items-center gap-1 w-fit">
                          <AlertCircle className="w-3 h-3" />
                          Yet to Report
                        </Badge>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-slate-800/80 backdrop-blur-md border-b border-slate-700 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center border-2 border-slate-600">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">PARADE STATE MONITORING</h1>
              <p className="text-xs text-blue-400">Command Dashboard</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="border-blue-500 text-blue-400 hover:bg-blue-900/30"
            >
              <Printer className="w-4 h-4 mr-2" />
              Print Report
            </Button>
            <Badge className="bg-green-600/80 text-white">Full Clearance</Badge>
            <div className="text-right hidden sm:block">
              <p className="text-sm text-slate-300">{user.name}</p>
              <p className="text-xs text-slate-500">{user.role === 'commanding-officer' ? 'Commanding Officer' : 'Executive Officer'}</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onLogout}
              className="text-slate-400 hover:text-white hover:bg-slate-700"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Date Display */}
        <div className="flex items-center gap-2 text-slate-400 mb-6">
          <Clock className="w-4 h-4" />
          <span className="text-sm">{currentDate}</span>
        </div>

        {/* Statistics Cards - Clickable */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-8">
          {Object.entries(statistics).map(([label, value]) => (
            <button
              key={label}
              onClick={() => handleStatClick(label)}
              className="text-left transition-transform hover:scale-[1.02]"
            >
              <Card className="border-slate-700 bg-slate-800/90 hover:border-blue-500 cursor-pointer transition-colors">
                <CardContent className="p-4">
                  <p className="text-2xl font-bold text-white">{value}</p>
                  <p className="text-xs text-slate-400">{label}</p>
                  <div className={cn("h-1 rounded-full mt-2", statColors[label] || 'bg-slate-500')} />
                </CardContent>
              </Card>
            </button>
          ))}
        </div>

        {/* Staff List by Rank */}
        <Card className="border-slate-700 bg-slate-800/90 backdrop-blur-sm">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex items-center gap-3">
                <BarChart3 className="w-5 h-5 text-blue-400" />
                <CardTitle className="text-lg text-white">Parade State Overview</CardTitle>
                <Badge className="bg-slate-700 text-slate-300">
                  {filteredStaff.length} of {totalStaff}
                </Badge>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3">
                {/* Status Filter */}
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-slate-400" />
                  <select
                    value={statusFilter === null ? 'yet-to-report' : statusFilter}
                    onChange={(e) => {
                      const value = e.target.value;
                      if (value === 'yet-to-report') {
                        setStatusFilter(null);
                      } else if (value === 'all') {
                        setStatusFilter('all');
                      } else {
                        setStatusFilter(value as StaffStatus);
                      }
                    }}
                    className="bg-slate-900 border border-slate-600 text-white text-sm rounded-lg px-3 py-2 focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="all">All Status</option>
                    {statusOptions.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                    <option value="yet-to-report">Yet to Report</option>
                  </select>
                </div>

                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    type="text"
                    placeholder="Search personnel..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-slate-900 border-slate-600 text-white placeholder:text-slate-500 w-full sm:w-64"
                  />
                </div>
              </div>
            </div>
          </CardHeader>
          
          <CardContent>
            {renderStaffTable(staffByRank.officers.filter(s => {
              if (statusFilter === 'all') return true;
              return s.todayStatus === statusFilter;
            }).filter(s => 
              s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
              s.serviceNumber.toLowerCase().includes(searchQuery.toLowerCase())
            ), 'Section A - Officers')}

            {renderStaffTable(staffByRank.seniorRates.filter(s => {
              if (statusFilter === 'all') return true;
              return s.todayStatus === statusFilter;
            }).filter(s => 
              s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
              s.serviceNumber.toLowerCase().includes(searchQuery.toLowerCase())
            ), 'Section B - Senior Rates')}

            {renderStaffTable(staffByRank.juniorRates.filter(s => {
              if (statusFilter === 'all') return true;
              return s.todayStatus === statusFilter;
            }).filter(s => 
              s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
              s.serviceNumber.toLowerCase().includes(searchQuery.toLowerCase())
            ), 'Section C - Junior Rates')}

            {filteredStaff.length === 0 && (
              <div className="text-center py-12">
                <Users className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                <p className="text-slate-400">No personnel found matching your criteria</p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      {/* Detail Modal */}
      {showDetailModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-xl border border-slate-700 w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-4 border-b border-slate-700 flex items-center justify-between">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-blue-400" />
                {getDetailTitle()} ({getDetailStaff().length})
              </h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowDetailModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            <div className="p-4 overflow-y-auto flex-1">
              {getDetailStaff().length === 0 ? (
                <p className="text-center text-slate-400 py-8">No personnel in this category</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-slate-700">
                        <th className="text-left py-3 px-4 text-slate-400 font-medium text-sm">Service Number</th>
                        <th className="text-left py-3 px-4 text-slate-400 font-medium text-sm">Rank & Name</th>
                        <th className="text-left py-3 px-4 text-slate-400 font-medium text-sm">Rank Category</th>
                        <th className="text-left py-3 px-4 text-slate-400 font-medium text-sm">Department</th>
                        <th className="text-left py-3 px-4 text-slate-400 font-medium text-sm">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {getDetailStaff().map((staff) => {
                        const statusConfig = staff.todayStatus 
                          ? statusOptions.find(s => s.value === staff.todayStatus) 
                          : null;
                        const StatusIcon = statusConfig ? iconMap[statusConfig.icon] : null;
                        
                        return (
                          <tr key={staff.serviceNumber} className="border-b border-slate-700/50 hover:bg-slate-700/30">
                            <td className="py-3 px-4">
                              <span className="font-mono text-slate-300">{staff.serviceNumber}</span>
                            </td>
                            <td className="py-3 px-4">
                              <span className="text-white font-medium">{staff.rank} {staff.name}</span>
                            </td>
                            <td className="py-3 px-4">
                              <span className="text-slate-400">{rankLabels[staff.rankCategory]}</span>
                            </td>
                            <td className="py-3 px-4">
                              <span className="text-slate-400">{staff.department}</span>
                            </td>
                            <td className="py-3 px-4">
                              {statusConfig ? (
                                <Badge className={cn("flex items-center gap-1 w-fit", statusConfig.color)}>
                                  {StatusIcon && <StatusIcon className="w-3 h-3" />}
                                  {statusConfig.label}
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="border-yellow-600 text-yellow-500 flex items-center gap-1 w-fit">
                                  <AlertCircle className="w-3 h-3" />
                                  Yet to Report
                                </Badge>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
