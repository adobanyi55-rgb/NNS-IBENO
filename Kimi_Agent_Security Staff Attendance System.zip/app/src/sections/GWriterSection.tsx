import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Shield, 
  LogOut, 
  UserPlus, 
  UserMinus,
  UserCog,
  ClipboardCheck,
  Users,
  Search,
  Check,
  AlertCircle,
  User,
  Building2,
  Briefcase,
  CheckCircle2,
  Trash2,
  Moon,
  Ticket,
  HeartPulse,
  Target,
  Clock,
  Plane,
  Anchor,
  Ship,
  Edit2,
  X
} from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { Staff, StaffStatus, User as UserType, StaffRank } from '@/types';
import { statusOptions, allRanks } from '@/data/staff';
import { cn } from '@/lib/utils';

interface GWriterSectionProps {
  user: UserType;
  staffList: Staff[];
  onLogout: () => void;
  onRegisterStaff: (staff: Staff) => boolean;
  onEditStaff: (serviceNumber: string, updatedStaff: Partial<Staff>) => boolean;
  onRemoveStaff: (serviceNumber: string) => boolean;
  onSubmitAttendance: (serviceNumber: string, status: StaffStatus) => boolean;
  getTodayStatus: (serviceNumber: string) => StaffStatus | undefined;
}

const iconMap: Record<string, React.ElementType> = {
  Ship,
  Anchor,
  Moon,
  Ticket,
  Plane,
  Briefcase,
  HeartPulse,
  Target,
  Clock,
};

export function GWriterSection({ 
  user, 
  staffList, 
  onLogout, 
  onRegisterStaff,
  onEditStaff,
  onRemoveStaff,
  onSubmitAttendance,
  getTodayStatus
}: GWriterSectionProps) {
  const [activeTab, setActiveTab] = useState<'attendance' | 'register' | 'edit' | 'remove'>('attendance');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<StaffStatus | null>(null);
  
  // Registration form state
  const [newStaff, setNewStaff] = useState({ 
    serviceNumber: '', 
    name: '', 
    department: '', 
    position: '',
    rank: 'Ordinary Seaman' as StaffRank,
    rankCategory: 'junior-rate' as 'officer' | 'senior-rate' | 'junior-rate'
  });
  const [registerError, setRegisterError] = useState('');
  const [registerSuccess, setRegisterSuccess] = useState(false);
  
  // Edit staff state
  const [editServiceNumber, setEditServiceNumber] = useState('');
  const [editForm, setEditForm] = useState<Partial<Staff>>({});
  const [editError, setEditError] = useState('');
  const [editSuccess, setEditSuccess] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  
  // Remove staff state
  const [removeServiceNumber, setRemoveServiceNumber] = useState('');
  const [removeError, setRemoveError] = useState('');
  const [removeSuccess, setRemoveSuccess] = useState(false);
  
  // Attendance submission state
  const [attendanceSuccess, setAttendanceSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const filteredStaff = staffList.filter(staff => 
    staff.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    staff.serviceNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegisterError('');
    setRegisterSuccess(false);

    if (!newStaff.serviceNumber || !newStaff.name || !newStaff.department || !newStaff.position) {
      setRegisterError('All fields are required');
      return;
    }

    const success = onRegisterStaff({
      serviceNumber: newStaff.serviceNumber.toUpperCase(),
      name: newStaff.name,
      department: newStaff.department,
      position: newStaff.position,
      rank: newStaff.rank,
      rankCategory: newStaff.rankCategory,
    });

    if (success) {
      setRegisterSuccess(true);
      setNewStaff({ serviceNumber: '', name: '', department: '', position: '', rank: 'Ordinary Seaman', rankCategory: 'junior-rate' });
    } else {
      setRegisterError('Service Number already exists');
    }
  };

  const handleEditSearch = () => {
    setEditError('');
    setEditSuccess(false);
    setIsEditing(false);
    setEditForm({});

    const staff = staffList.find(s => s.serviceNumber.toUpperCase() === editServiceNumber.toUpperCase());
    if (staff) {
      setEditForm({ ...staff });
      setIsEditing(true);
    } else {
      setEditError('Service Number not found');
    }
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setEditError('');
    setEditSuccess(false);

    if (!editForm.name || !editForm.department || !editForm.position || !editForm.rank) {
      setEditError('All fields are required');
      return;
    }

    // Determine rank category based on selected rank
    let rankCategory: 'officer' | 'senior-rate' | 'junior-rate' = 'junior-rate';
    if (allRanks.officer.includes(editForm.rank)) {
      rankCategory = 'officer';
    } else if (allRanks['senior-rate'].includes(editForm.rank)) {
      rankCategory = 'senior-rate';
    }

    const success = onEditStaff(editServiceNumber, {
      ...editForm,
      rankCategory,
    });

    if (success) {
      setEditSuccess(true);
      setTimeout(() => {
        setIsEditing(false);
        setEditServiceNumber('');
        setEditForm({});
      }, 1500);
    } else {
      setEditError('Failed to update staff');
    }
  };

  const handleRemove = (e: React.FormEvent) => {
    e.preventDefault();
    setRemoveError('');
    setRemoveSuccess(false);

    if (!removeServiceNumber.trim()) {
      setRemoveError('Please enter a Service Number');
      return;
    }

    const success = onRemoveStaff(removeServiceNumber.trim());

    if (success) {
      setRemoveSuccess(true);
      setRemoveServiceNumber('');
    } else {
      setRemoveError('Service Number not found');
    }
  };

  const handleSubmitAttendance = () => {
    if (!selectedStaff || !selectedStatus) return;
    
    setIsSubmitting(true);
    
    setTimeout(() => {
      const success = onSubmitAttendance(selectedStaff.serviceNumber, selectedStatus);
      if (success) {
        setAttendanceSuccess(true);
        setTimeout(() => {
          setSelectedStaff(null);
          setSelectedStatus(null);
          setAttendanceSuccess(false);
        }, 1500);
      }
      setIsSubmitting(false);
    }, 300);
  };

  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const getAvailableRanks = () => {
    return [
      { label: '--- Officers ---', options: allRanks.officer },
      { label: '--- Senior Rates ---', options: allRanks['senior-rate'] },
      { label: '--- Junior Rates ---', options: allRanks['junior-rate'] },
    ];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-slate-800/80 backdrop-blur-md border-b border-slate-700 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center border-2 border-slate-600">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">PARADE STATE MONITORING</h1>
              <p className="text-xs text-blue-400">G-Writer Terminal</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Badge className="bg-yellow-600/80 text-white">Limited Access</Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={onLogout}
              className="text-slate-400 hover:text-white hover:bg-slate-700"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Welcome & Date */}
        <div className="mb-6">
          <p className="text-slate-400 text-sm mb-1">{currentDate}</p>
          <h2 className="text-xl font-bold text-white">
            Welcome, <span className="text-blue-400">{user.name}</span>
          </h2>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-2 mb-6">
          <Button
            variant={activeTab === 'attendance' ? 'default' : 'outline'}
            onClick={() => setActiveTab('attendance')}
            className={activeTab === 'attendance' ? 'bg-blue-600' : 'border-slate-600 text-slate-300'}
          >
            <ClipboardCheck className="w-4 h-4 mr-2" />
            Log Attendance
          </Button>
          <Button
            variant={activeTab === 'register' ? 'default' : 'outline'}
            onClick={() => setActiveTab('register')}
            className={activeTab === 'register' ? 'bg-blue-600' : 'border-slate-600 text-slate-300'}
          >
            <UserPlus className="w-4 h-4 mr-2" />
            Register Staff
          </Button>
          <Button
            variant={activeTab === 'edit' ? 'default' : 'outline'}
            onClick={() => setActiveTab('edit')}
            className={activeTab === 'edit' ? 'bg-amber-600' : 'border-slate-600 text-slate-300'}
          >
            <UserCog className="w-4 h-4 mr-2" />
            Edit Staff
          </Button>
          <Button
            variant={activeTab === 'remove' ? 'default' : 'outline'}
            onClick={() => setActiveTab('remove')}
            className={activeTab === 'remove' ? 'bg-red-600' : 'border-slate-600 text-slate-300'}
          >
            <UserMinus className="w-4 h-4 mr-2" />
            Remove Staff
          </Button>
        </div>

        {activeTab === 'register' ? (
          <Card className="border-slate-700 bg-slate-800/90 backdrop-blur-sm max-w-2xl">
            <CardHeader>
              <CardTitle className="text-lg text-white flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-blue-400" />
                Register New Staff
              </CardTitle>
              <CardDescription className="text-slate-400">
                Add a new personnel to the system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleRegister} className="space-y-4">
                {registerError && (
                  <Alert variant="destructive" className="bg-red-900/50 border-red-700">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{registerError}</AlertDescription>
                  </Alert>
                )}
                {registerSuccess && (
                  <Alert className="bg-green-900/50 border-green-700">
                    <CheckCircle2 className="h-4 w-4 text-green-400" />
                    <AlertDescription className="text-green-400">Staff registered successfully!</AlertDescription>
                  </Alert>
                )}
                
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Service Number</label>
                    <Input
                      value={newStaff.serviceNumber}
                      onChange={(e) => setNewStaff({ ...newStaff, serviceNumber: e.target.value.toUpperCase() })}
                      placeholder="e.g., SN78447"
                      className="bg-slate-900 border-slate-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Full Name</label>
                    <Input
                      value={newStaff.name}
                      onChange={(e) => setNewStaff({ ...newStaff, name: e.target.value })}
                      placeholder="Enter full name"
                      className="bg-slate-900 border-slate-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Department</label>
                    <Input
                      value={newStaff.department}
                      onChange={(e) => setNewStaff({ ...newStaff, department: e.target.value })}
                      placeholder="e.g., Engineering"
                      className="bg-slate-900 border-slate-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Position</label>
                    <Input
                      value={newStaff.position}
                      onChange={(e) => setNewStaff({ ...newStaff, position: e.target.value })}
                      placeholder="e.g., Engineering Officer"
                      className="bg-slate-900 border-slate-600 text-white"
                    />
                  </div>
                  <div className="space-y-2 sm:col-span-2">
                    <label className="text-sm font-medium text-slate-300">Rank</label>
                    <select
                      value={newStaff.rank}
                      onChange={(e) => {
                        const rank = e.target.value as StaffRank;
                        let rankCategory: 'officer' | 'senior-rate' | 'junior-rate' = 'junior-rate';
                        if (allRanks.officer.includes(rank)) rankCategory = 'officer';
                        else if (allRanks['senior-rate'].includes(rank)) rankCategory = 'senior-rate';
                        setNewStaff({ ...newStaff, rank, rankCategory });
                      }}
                      className="w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-3 py-2 focus:border-blue-500 focus:ring-blue-500"
                    >
                      {getAvailableRanks().map((group) => (
                        <optgroup key={group.label} label={group.label}>
                          {group.options.map((rank) => (
                            <option key={rank} value={rank}>{rank}</option>
                          ))}
                        </optgroup>
                      ))}
                    </select>
                  </div>
                </div>

                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Register Staff
                </Button>
              </form>
            </CardContent>
          </Card>
        ) : activeTab === 'edit' ? (
          <Card className="border-slate-700 bg-slate-800/90 backdrop-blur-sm max-w-2xl">
            <CardHeader>
              <CardTitle className="text-lg text-white flex items-center gap-2">
                <UserCog className="w-5 h-5 text-amber-400" />
                Edit Staff Details
              </CardTitle>
              <CardDescription className="text-slate-400">
                Search and modify personnel information
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!isEditing ? (
                <div className="space-y-4">
                  {editError && (
                    <Alert variant="destructive" className="bg-red-900/50 border-red-700">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{editError}</AlertDescription>
                    </Alert>
                  )}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Service Number</label>
                    <div className="flex gap-2">
                      <Input
                        value={editServiceNumber}
                        onChange={(e) => setEditServiceNumber(e.target.value.toUpperCase())}
                        placeholder="Enter service number to edit"
                        className="bg-slate-900 border-slate-600 text-white flex-1"
                      />
                      <Button onClick={handleEditSearch} className="bg-amber-600 hover:bg-amber-700">
                        <Search className="w-4 h-4 mr-2" />
                        Search
                      </Button>
                    </div>
                  </div>

                  {/* Current Staff List */}
                  <div className="mt-6 pt-6 border-t border-slate-700">
                    <h3 className="text-sm font-medium text-slate-300 mb-4">Click to Edit ({staffList.length})</h3>
                    <div className="max-h-64 overflow-y-auto space-y-2">
                      {staffList.map((staff) => (
                        <button
                          key={staff.serviceNumber}
                          onClick={() => {
                            setEditServiceNumber(staff.serviceNumber);
                            setEditForm({ ...staff });
                            setIsEditing(true);
                            setEditError('');
                          }}
                          className="w-full flex items-center justify-between p-3 bg-slate-900 rounded-lg text-left hover:bg-slate-800 transition-colors"
                        >
                          <div>
                            <p className="text-white font-medium">{staff.name}</p>
                            <p className="text-xs text-slate-400">{staff.serviceNumber} • {staff.rank}</p>
                          </div>
                          <Edit2 className="w-4 h-4 text-slate-500" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleEditSubmit} className="space-y-4">
                  {editError && (
                    <Alert variant="destructive" className="bg-red-900/50 border-red-700">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{editError}</AlertDescription>
                    </Alert>
                  )}
                  {editSuccess && (
                    <Alert className="bg-green-900/50 border-green-700">
                      <CheckCircle2 className="h-4 w-4 text-green-400" />
                      <AlertDescription className="text-green-400">Staff updated successfully!</AlertDescription>
                    </Alert>
                  )}

                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm text-slate-400">Editing: <span className="text-white font-mono">{editServiceNumber}</span></p>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setIsEditing(false);
                        setEditServiceNumber('');
                        setEditForm({});
                      }}
                      className="text-slate-400"
                    >
                      <X className="w-4 h-4 mr-1" />
                      Cancel
                    </Button>
                  </div>
                  
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-300">Full Name</label>
                      <Input
                        value={editForm.name || ''}
                        onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                        placeholder="Enter full name"
                        className="bg-slate-900 border-slate-600 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-300">Department</label>
                      <Input
                        value={editForm.department || ''}
                        onChange={(e) => setEditForm({ ...editForm, department: e.target.value })}
                        placeholder="e.g., Engineering"
                        className="bg-slate-900 border-slate-600 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-300">Position</label>
                      <Input
                        value={editForm.position || ''}
                        onChange={(e) => setEditForm({ ...editForm, position: e.target.value })}
                        placeholder="e.g., Engineering Officer"
                        className="bg-slate-900 border-slate-600 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-300">Rank</label>
                      <select
                        value={editForm.rank || ''}
                        onChange={(e) => setEditForm({ ...editForm, rank: e.target.value as StaffRank })}
                        className="w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-3 py-2 focus:border-blue-500 focus:ring-blue-500"
                      >
                        {getAvailableRanks().map((group) => (
                          <optgroup key={group.label} label={group.label}>
                            {group.options.map((rank) => (
                              <option key={rank} value={rank}>{rank}</option>
                            ))}
                          </optgroup>
                        ))}
                      </select>
                    </div>
                  </div>

                  <Button type="submit" className="w-full bg-amber-600 hover:bg-amber-700">
                    <Edit2 className="w-4 h-4 mr-2" />
                    Update Staff
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        ) : activeTab === 'remove' ? (
          <Card className="border-slate-700 bg-slate-800/90 backdrop-blur-sm max-w-2xl">
            <CardHeader>
              <CardTitle className="text-lg text-white flex items-center gap-2">
                <UserMinus className="w-5 h-5 text-red-400" />
                Remove Staff
              </CardTitle>
              <CardDescription className="text-slate-400">
                Remove a personnel from the system permanently
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleRemove} className="space-y-4">
                {removeError && (
                  <Alert variant="destructive" className="bg-red-900/50 border-red-700">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{removeError}</AlertDescription>
                  </Alert>
                )}
                {removeSuccess && (
                  <Alert className="bg-green-900/50 border-green-700">
                    <CheckCircle2 className="h-4 w-4 text-green-400" />
                    <AlertDescription className="text-green-400">Staff removed successfully!</AlertDescription>
                  </Alert>
                )}
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-300">Service Number</label>
                  <Input
                    value={removeServiceNumber}
                    onChange={(e) => setRemoveServiceNumber(e.target.value.toUpperCase())}
                    placeholder="Enter service number to remove"
                    className="bg-slate-900 border-slate-600 text-white"
                  />
                </div>

                <Alert className="bg-yellow-900/30 border-yellow-700">
                  <AlertCircle className="h-4 w-4 text-yellow-500" />
                  <AlertDescription className="text-yellow-400">
                    Warning: This action cannot be undone. The staff member and all their attendance records will be permanently deleted.
                  </AlertDescription>
                </Alert>

                <Button type="submit" className="w-full bg-red-600 hover:bg-red-700">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Remove Staff
                </Button>
              </form>

              {/* Current Staff List */}
              <div className="mt-8 pt-6 border-t border-slate-700">
                <h3 className="text-sm font-medium text-slate-300 mb-4">Current Personnel ({staffList.length})</h3>
                <div className="max-h-64 overflow-y-auto space-y-2">
                  {staffList.map((staff) => (
                    <div key={staff.serviceNumber} className="flex items-center justify-between p-3 bg-slate-900 rounded-lg">
                      <div>
                        <p className="text-white font-medium">{staff.name}</p>
                        <p className="text-xs text-slate-400">{staff.serviceNumber} • {staff.rank}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setRemoveServiceNumber(staff.serviceNumber);
                        }}
                        className="text-slate-400 hover:text-red-400"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Staff Selection */}
            <Card className="border-slate-700 bg-slate-800/90 backdrop-blur-sm lg:col-span-1">
              <CardHeader>
                <CardTitle className="text-lg text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-blue-400" />
                  Select Personnel
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative mb-4">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="Search by name or SN..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-slate-900 border-slate-600 text-white"
                  />
                </div>
                
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {filteredStaff.map((staff) => {
                    const todayStatus = getTodayStatus(staff.serviceNumber);
                    const statusConfig = todayStatus ? statusOptions.find(s => s.value === todayStatus) : null;
                    
                    return (
                      <button
                        key={staff.serviceNumber}
                        onClick={() => {
                          setSelectedStaff(staff);
                          setSelectedStatus(null);
                          setAttendanceSuccess(false);
                        }}
                        className={cn(
                          "w-full p-3 rounded-lg text-left transition-all border",
                          selectedStaff?.serviceNumber === staff.serviceNumber
                            ? "bg-blue-900/30 border-blue-500"
                            : "bg-slate-900 border-slate-700 hover:border-slate-600"
                        )}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-white font-medium">{staff.name}</p>
                            <p className="text-xs text-slate-400">{staff.serviceNumber} • {staff.rank}</p>
                          </div>
                          {statusConfig && (
                            <Badge className={cn("text-xs", statusConfig.color)}>
                              {statusConfig.label}
                            </Badge>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Status Selection */}
            <Card className="border-slate-700 bg-slate-800/90 backdrop-blur-sm lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg text-white flex items-center gap-2">
                  <ClipboardCheck className="w-5 h-5 text-blue-400" />
                  Log Status
                </CardTitle>
                <CardDescription className="text-slate-400">
                  {selectedStaff 
                    ? `Recording attendance for ${selectedStaff.name}` 
                    : 'Select a personnel to log their status'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {selectedStaff ? (
                  <>
                    {/* Selected Staff Info */}
                    <div className="bg-slate-900 rounded-lg p-4 mb-6 border border-slate-700">
                      <div className="grid sm:grid-cols-4 gap-4">
                        <div className="flex items-center gap-3">
                          <User className="w-5 h-5 text-slate-400" />
                          <div>
                            <p className="text-xs text-slate-500">Name</p>
                            <p className="text-white font-medium">{selectedStaff.name}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Building2 className="w-5 h-5 text-slate-400" />
                          <div>
                            <p className="text-xs text-slate-500">Department</p>
                            <p className="text-white font-medium">{selectedStaff.department}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Briefcase className="w-5 h-5 text-slate-400" />
                          <div>
                            <p className="text-xs text-slate-500">Position</p>
                            <p className="text-white font-medium">{selectedStaff.position}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Shield className="w-5 h-5 text-slate-400" />
                          <div>
                            <p className="text-xs text-slate-500">Rank</p>
                            <p className="text-white font-medium">{selectedStaff.rank}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Status Grid */}
                    <div className="grid grid-cols-3 sm:grid-cols-5 gap-3 mb-6">
                      {statusOptions.map((option) => {
                        const Icon = iconMap[option.icon];
                        const isSelected = selectedStatus === option.value;
                        
                        return (
                          <button
                            key={option.value}
                            onClick={() => setSelectedStatus(option.value as StaffStatus)}
                            className={cn(
                              "relative p-3 rounded-xl border-2 transition-all duration-200 text-center",
                              "hover:scale-[1.02] hover:shadow-lg",
                              isSelected
                                ? "border-blue-500 bg-blue-900/20"
                                : "border-slate-600 bg-slate-800 hover:border-slate-500"
                            )}
                          >
                            <div className={cn(
                              "w-10 h-10 rounded-lg flex items-center justify-center mx-auto mb-2",
                              option.color
                            )}>
                              <Icon className="w-5 h-5 text-white" />
                            </div>
                            <p className="text-xs font-medium text-white">{option.label}</p>
                            
                            {isSelected && (
                              <div className="absolute top-1 right-1">
                                <div className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center">
                                  <Check className="w-3 h-3 text-white" />
                                </div>
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Submit Button */}
                    <Button
                      onClick={handleSubmitAttendance}
                      disabled={!selectedStatus || isSubmitting}
                      className={cn(
                        "w-full py-3 font-semibold transition-all",
                        selectedStatus
                          ? "bg-blue-600 hover:bg-blue-700 text-white"
                          : "bg-slate-700 text-slate-500 cursor-not-allowed"
                      )}
                    >
                      {isSubmitting ? 'Submitting...' : 'Log Attendance'}
                    </Button>

                    {/* Success Message */}
                    {attendanceSuccess && (
                      <Alert className="mt-4 bg-green-900/50 border-green-700">
                        <CheckCircle2 className="h-4 w-4 text-green-400" />
                        <AlertDescription className="text-green-400">
                          Attendance logged successfully for {selectedStaff.name}!
                        </AlertDescription>
                      </Alert>
                    )}
                  </>
                ) : (
                  <div className="text-center py-12 text-slate-500">
                    <Users className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p>Select a personnel from the list to log their attendance status</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
