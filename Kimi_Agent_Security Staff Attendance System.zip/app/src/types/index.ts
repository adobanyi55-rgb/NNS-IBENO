export type StaffStatus = 
  | 'onboard' 
  | 'ashore' 
  | 'off-duty' 
  | 'pass' 
  | 'leave' 
  | 'temp-duty' 
  | 'sick' 
  | 'operations' 
  | 'yet-to-report';

export type UserRole = 'commanding-officer' | 'executive-officer' | 'g-writer' | null;

// Expanded rank structure
export type OfficerRank = 
  | 'Midshipman'
  | 'Acting Sub-Lieutenant'
  | 'Sub-Lieutenant'
  | 'Lieutenant'
  | 'Lieutenant Commander'
  | 'Commander'
  | 'Captain'
  | 'Commodore'
  | 'Rear Admiral'
  | 'Vice Admiral';

export type SeniorRateRank = 
  | 'Leading Seaman'
  | 'Petty Officer'
  | 'Chief Petty Officer'
  | 'Warrant Officer'
  | 'Master Warrant Officer';

export type JuniorRateRank = 
  | 'Ordinary Seaman'
  | 'Able Seaman';

export type StaffRank = OfficerRank | SeniorRateRank | JuniorRateRank;

export interface Staff {
  serviceNumber: string;
  name: string;
  department: string;
  position: string;
  rank: StaffRank;
  rankCategory: 'officer' | 'senior-rate' | 'junior-rate';
}

export interface AttendanceRecord {
  serviceNumber: string;
  status: StaffStatus;
  date: string;
  timestamp: number;
  loggedBy?: string;
}

export interface StaffWithAttendance extends Staff {
  todayStatus?: StaffStatus;
}

export interface User {
  role: UserRole;
  name: string;
  accessCode: string;
}
