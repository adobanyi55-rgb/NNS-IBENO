import type { Staff } from '@/types';

export const staffDatabase: Staff[] = [
  // Officers (Midshipman to Vice Admiral)
  { serviceNumber: 'SN78432', name: 'John Mitchell', department: 'Command', position: 'Commanding Officer', rank: 'Captain', rankCategory: 'officer' },
  { serviceNumber: 'SN78433', name: 'Sarah Johnson', department: 'Operations', position: 'Executive Officer', rank: 'Commander', rankCategory: 'officer' },
  { serviceNumber: 'SN78434', name: 'Michael Chen', department: 'Navigation', position: 'Navigation Officer', rank: 'Lieutenant Commander', rankCategory: 'officer' },
  { serviceNumber: 'SN78435', name: 'Emily Rodriguez', department: 'Engineering', position: 'Engineering Officer', rank: 'Lieutenant', rankCategory: 'officer' },
  { serviceNumber: 'SN78436', name: 'David Williams', department: 'Communications', position: 'Communications Officer', rank: 'Sub-Lieutenant', rankCategory: 'officer' },
  
  // Senior Rates (Leading Seaman to Master Warrant Officer)
  { serviceNumber: 'SN78437', name: 'Robert Taylor', department: 'Deck Department', position: 'Boatswain', rank: 'Master Warrant Officer', rankCategory: 'senior-rate' },
  { serviceNumber: 'SN78438', name: 'Lisa Anderson', department: 'Engineering', position: 'Chief Engineering Rate', rank: 'Warrant Officer', rankCategory: 'senior-rate' },
  { serviceNumber: 'SN78439', name: 'Jennifer Brown', department: 'Operations', position: 'Operations Supervisor', rank: 'Chief Petty Officer', rankCategory: 'senior-rate' },
  { serviceNumber: 'SN78440', name: 'James Wilson', department: 'Communications', position: 'Communications Supervisor', rank: 'Petty Officer', rankCategory: 'senior-rate' },
  { serviceNumber: 'SN78441', name: 'Maria Garcia', department: 'Deck Department', position: 'Deck Supervisor', rank: 'Leading Seaman', rankCategory: 'senior-rate' },
  
  // Junior Rates (Ordinary Seaman to Able Seaman)
  { serviceNumber: 'SN78442', name: 'William Martinez', department: 'Deck Department', position: 'Deck Hand', rank: 'Able Seaman', rankCategory: 'junior-rate' },
  { serviceNumber: 'SN78443', name: 'Patricia Lee', department: 'Engineering', position: 'Engineering Hand', rank: 'Able Seaman', rankCategory: 'junior-rate' },
  { serviceNumber: 'SN78444', name: 'Thomas Hall', department: 'Operations', position: 'Operations Hand', rank: 'Ordinary Seaman', rankCategory: 'junior-rate' },
  { serviceNumber: 'SN78445', name: 'Linda Clark', department: 'Communications', position: 'Communications Hand', rank: 'Ordinary Seaman', rankCategory: 'junior-rate' },
  { serviceNumber: 'SN78446', name: 'Charles Lewis', department: 'Deck Department', position: 'Deck Trainee', rank: 'Ordinary Seaman', rankCategory: 'junior-rate' },
];

export const statusOptions = [
  { value: 'onboard', label: 'Onboard', color: 'bg-green-600', icon: 'Ship' },
  { value: 'ashore', label: 'Ashore', color: 'bg-blue-600', icon: 'Anchor' },
  { value: 'off-duty', label: 'Off Duty', color: 'bg-slate-500', icon: 'Moon' },
  { value: 'pass', label: 'Pass', color: 'bg-teal-500', icon: 'Ticket' },
  { value: 'leave', label: 'Leave', color: 'bg-indigo-500', icon: 'Plane' },
  { value: 'temp-duty', label: 'Temporary Duty', color: 'bg-purple-500', icon: 'Briefcase' },
  { value: 'sick', label: 'Sick', color: 'bg-red-500', icon: 'HeartPulse' },
  { value: 'operations', label: 'Operations', color: 'bg-orange-500', icon: 'Target' },
  { value: 'yet-to-report', label: 'Yet to Report', color: 'bg-yellow-500', icon: 'Clock' },
] as const;

export const rankLabels: Record<string, string> = {
  'officer': 'Officers',
  'senior-rate': 'Senior Rates',
  'junior-rate': 'Junior Rates',
};

// Rank options for dropdown
export const officerRanks: string[] = [
  'Midshipman',
  'Acting Sub-Lieutenant',
  'Sub-Lieutenant',
  'Lieutenant',
  'Lieutenant Commander',
  'Commander',
  'Captain',
  'Commodore',
  'Rear Admiral',
  'Vice Admiral',
];

export const seniorRateRanks: string[] = [
  'Leading Seaman',
  'Petty Officer',
  'Chief Petty Officer',
  'Warrant Officer',
  'Master Warrant Officer',
];

export const juniorRateRanks: string[] = [
  'Ordinary Seaman',
  'Able Seaman',
];

export const allRanks = {
  officer: officerRanks,
  'senior-rate': seniorRateRanks,
  'junior-rate': juniorRateRanks,
};
