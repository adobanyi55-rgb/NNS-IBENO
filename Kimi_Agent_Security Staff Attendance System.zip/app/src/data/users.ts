import type { User } from '@/types';

export const users: User[] = [
  {
    role: 'commanding-officer',
    name: 'Commanding Officer',
    accessCode: 'CO2024',
  },
  {
    role: 'executive-officer',
    name: 'Executive Officer',
    accessCode: 'XO2024',
  },
  {
    role: 'g-writer',
    name: 'G-Writer',
    accessCode: 'GW2024',
  },
];

export function authenticateUser(accessCode: string): User | null {
  const user = users.find(u => u.accessCode.toUpperCase() === accessCode.toUpperCase());
  return user || null;
}
