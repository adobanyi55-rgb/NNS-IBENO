import { useState, useEffect, useCallback } from 'react';
import type { Staff, AttendanceRecord, StaffStatus, User } from '@/types';
import { staffDatabase as initialStaff } from '@/data/staff';
import { authenticateUser } from '@/data/users';

const ATTENDANCE_STORAGE_KEY = 'parade_attendance_records';
const STAFF_STORAGE_KEY = 'parade_staff_database';

export function useAttendance() {
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [staffDatabase, setStaffDatabase] = useState<Staff[]>(initialStaff);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load data from localStorage on mount
  useEffect(() => {
    const storedRecords = localStorage.getItem(ATTENDANCE_STORAGE_KEY);
    const storedStaff = localStorage.getItem(STAFF_STORAGE_KEY);
    
    if (storedRecords) {
      try {
        const parsed = JSON.parse(storedRecords);
        setRecords(parsed);
      } catch (e) {
        console.error('Failed to parse attendance records:', e);
      }
    }
    
    if (storedStaff) {
      try {
        const parsed = JSON.parse(storedStaff);
        setStaffDatabase(parsed);
      } catch (e) {
        console.error('Failed to parse staff database:', e);
      }
    }
    
    setIsLoading(false);
  }, []);

  // Save records to localStorage whenever they change
  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem(ATTENDANCE_STORAGE_KEY, JSON.stringify(records));
    }
  }, [records, isLoading]);

  // Save staff database to localStorage whenever it changes
  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem(STAFF_STORAGE_KEY, JSON.stringify(staffDatabase));
    }
  }, [staffDatabase, isLoading]);

  const login = useCallback((accessCode: string): { success: boolean; user?: User } => {
    const user = authenticateUser(accessCode);
    if (user) {
      setCurrentUser(user);
      return { success: true, user };
    }
    return { success: false };
  }, []);

  const logout = useCallback(() => {
    setCurrentUser(null);
  }, []);

  const registerStaff = useCallback((staff: Staff): boolean => {
    // Check if service number already exists
    if (staffDatabase.some(s => s.serviceNumber.toUpperCase() === staff.serviceNumber.toUpperCase())) {
      return false;
    }
    
    setStaffDatabase(prev => [...prev, staff]);
    return true;
  }, [staffDatabase]);

  const editStaff = useCallback((serviceNumber: string, updatedStaff: Partial<Staff>): boolean => {
    const staffIndex = staffDatabase.findIndex(s => s.serviceNumber.toUpperCase() === serviceNumber.toUpperCase());
    if (staffIndex === -1) {
      return false;
    }
    
    setStaffDatabase(prev => {
      const newStaff = [...prev];
      newStaff[staffIndex] = { ...newStaff[staffIndex], ...updatedStaff };
      return newStaff;
    });
    
    return true;
  }, [staffDatabase]);

  const removeStaff = useCallback((serviceNumber: string): boolean => {
    const staffExists = staffDatabase.some(s => s.serviceNumber.toUpperCase() === serviceNumber.toUpperCase());
    if (!staffExists) {
      return false;
    }
    
    setStaffDatabase(prev => prev.filter(s => s.serviceNumber.toUpperCase() !== serviceNumber.toUpperCase()));
    
    // Also remove any attendance records for this staff
    setRecords(prev => prev.filter(r => r.serviceNumber.toUpperCase() !== serviceNumber.toUpperCase()));
    
    return true;
  }, [staffDatabase]);

  const submitAttendance = useCallback((serviceNumber: string, status: StaffStatus): boolean => {
    const staff = staffDatabase.find(s => s.serviceNumber.toUpperCase() === serviceNumber.toUpperCase());
    if (!staff) return false;

    const today = new Date().toISOString().split('T')[0];
    
    // Remove any existing record for today
    const filteredRecords = records.filter(
      r => !(r.serviceNumber === staff.serviceNumber && r.date === today)
    );

    // Add new record
    const newRecord: AttendanceRecord = {
      serviceNumber: staff.serviceNumber,
      status,
      date: today,
      timestamp: Date.now(),
      loggedBy: currentUser?.name,
    };

    setRecords([...filteredRecords, newRecord]);
    return true;
  }, [staffDatabase, records, currentUser]);

  const getTodayStatus = useCallback((serviceNumber: string): StaffStatus | undefined => {
    const today = new Date().toISOString().split('T')[0];
    const record = records.find(r => r.serviceNumber === serviceNumber && r.date === today);
    return record?.status;
  }, [records]);

  const getAllTodayRecords = useCallback(() => {
    const today = new Date().toISOString().split('T')[0];
    return records.filter(r => r.date === today);
  }, [records]);

  const getStaffWithAttendance = useCallback(() => {
    const today = new Date().toISOString().split('T')[0];
    return staffDatabase.map(staff => ({
      ...staff,
      todayStatus: records.find(r => r.serviceNumber === staff.serviceNumber && r.date === today)?.status,
    }));
  }, [staffDatabase, records]);

  const getStatistics = useCallback(() => {
    const today = new Date().toISOString().split('T')[0];
    const todayRecords = records.filter(r => r.date === today);
    const totalStaff = staffDatabase.length;
    const checkedIn = todayRecords.length;
    
    const stats: Record<string, number> = {
      'Strength': totalStaff,
      'Checked In': checkedIn,
      'Onboard': 0,
      'Ashore': 0,
      'Off Duty': 0,
      'Pass': 0,
      'Leave': 0,
      'Temp Duty': 0,
      'Sick': 0,
      'Operations': 0,
      'Yet to Report': totalStaff - checkedIn,
    };
    
    todayRecords.forEach(record => {
      const label = record.status
        .replace('off-duty', 'Off Duty')
        .replace('temp-duty', 'Temp Duty')
        .replace('yet-to-report', 'Yet to Report')
        .replace(/-/g, ' ')
        .replace(/\b\w/g, l => l.toUpperCase());
      
      if (stats[label] !== undefined) {
        stats[label]++;
      }
    });
    
    return stats;
  }, [staffDatabase, records]);

  // Get staff grouped by rank category
  const getStaffByRank = useCallback(() => {
    const today = new Date().toISOString().split('T')[0];
    const staffWithAttendance = staffDatabase.map(staff => ({
      ...staff,
      todayStatus: records.find(r => r.serviceNumber === staff.serviceNumber && r.date === today)?.status,
    }));

    return {
      officers: staffWithAttendance.filter(s => s.rankCategory === 'officer'),
      seniorRates: staffWithAttendance.filter(s => s.rankCategory === 'senior-rate'),
      juniorRates: staffWithAttendance.filter(s => s.rankCategory === 'junior-rate'),
    };
  }, [staffDatabase, records]);

  // Get staff by status for detail view
  const getStaffByStatus = useCallback((status: StaffStatus | null) => {
    const today = new Date().toISOString().split('T')[0];
    const staffWithAttendance = staffDatabase.map(staff => ({
      ...staff,
      todayStatus: records.find(r => r.serviceNumber === staff.serviceNumber && r.date === today)?.status,
    }));

    if (status === null) {
      // Return staff who haven't reported (yet-to-report)
      return staffWithAttendance.filter(s => !s.todayStatus);
    }

    return staffWithAttendance.filter(s => s.todayStatus === status);
  }, [staffDatabase, records]);

  return {
    currentUser,
    staffDatabase,
    isLoading,
    login,
    logout,
    registerStaff,
    editStaff,
    removeStaff,
    submitAttendance,
    getTodayStatus,
    getAllTodayRecords,
    getStaffWithAttendance,
    getStatistics,
    getStaffByRank,
    getStaffByStatus,
  };
}
